/*
*	CSC360 Assignment 03
*
*	Part IV
*
*	Student: Yaoxu Li
*	V00908578
*	Descripyion:  Copies a file from the current Unix directory into the file system.
*	Credit: The method using mmap() refrences previous years 360's tutorial.
*
*	Note: this part has some bugs
*/
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <time.h>

int main(int argc, char* argv[])
{
	//initialize
	int root_start = 0;
	int block_size = 0;
	int root_address = 0;
	int file_start_block = 0;
	int pre_start = 0;
	int pre_size = 0;

	int status = 0;
	size_t file_size = 0;
	int count = 0;

	char* file_name = argv[2];
	int fd = open(argv[1], O_RDWR);
	struct stat buffer;
	struct stat filestat;
	fstat(fd, &buffer);
	stat(file_name, &filestat);

	char* address = mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

	memcpy(&block_size, address + 8, 2);
	block_size = ntohs(block_size);
	memcpy(&root_start, address + 22, 4);
	root_start = ntohl(root_start);
	root_address = block_size*root_start;
	memcpy(&status, address + root_address, 1);

	//open the file
	FILE *fp;
	fp = fopen(file_name, "r");
	if ( fp == NULL) {
		perror("fopen()");
		return EXIT_FAILURE;
	}

	fseek(fp, 0, SEEK_END);
	//get file size
	file_size = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	

	while (status!=0) {
		memcpy(&pre_start, address +root_address+ (64 * count) + 1, 4);
		memcpy(&pre_size, address +root_address+ (64 * count) + 5, 4);
		count++;
		memcpy(&status, address + root_address + (64 * count), 1);
	}
	pre_start = ntohl(pre_start);
	pre_size = ntohl(pre_size);

	//write to file system
	fwrite(address + pre_start + pre_size,1,file_size,fp);

	file_size = htonl(file_size);
	
	status = 0x3;

	//update disk list
	file_start_block = pre_start + pre_size;
	file_start_block = htonl(file_start_block);
	memcpy(address + root_address + (64 * count),&status ,1);
	memcpy(address + root_address + (64 * count) + 1, &file_start_block,4);
	memcpy(address + root_address + (64 * count)+9, &file_size, 4);

	//update modification time 
	//this part not finished
	for (int i = 0; i < strlen(file_name); i++) {
		memcpy(address + root_address + (64 * count) + 27+i, &file_name[i], 1);
	}
	short year = filestat.st_mtime/(24*365*60*60)+1970;
	short month = (short) (filestat.st_mtime / (24 * 60 * 60 * 30.5)) % 12;
	year = htons(year);
	memcpy(address + root_address + (64 * count) + 20, &year, 2);
	memcpy(address + root_address + (64 * count) + 22, &month, 1);


	//end
	fclose(fp);
	printf("File %s from current directory has been copied to file system\n", file_name);
	exit(0);
}