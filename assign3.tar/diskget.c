/*
*	CSC360 Assignment 03
*
*	Part III
*
*	Student: Yaoxu Li
*	V00908578
*	Descripyion: Copies a file from the file system to the current directory in Unix.
*	Credit: The method using mmap() refrences previous years 360's tutorial.
*/
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <arpa/inet.h>


int main(int argc, char* argv[])
{
	int root_start = 0;
	int block_size = 0;
	int root_address = 0;
	int file_start_block = 0;

	//set 0 if the file exist
	int file_exist = -1;
	int status = 0;
	int file_size = 0;
	int count = 0;

	char* file_name = argv[2];
	int fd = open(argv[1], O_RDWR);
	struct stat buffer;
	fstat(fd, &buffer);

	char* address = mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	memcpy(&block_size, address + 8, 2);
	block_size = ntohs(block_size);
	memcpy(&root_start, address + 22, 4);
	root_start = ntohl(root_start);
	root_address = block_size*root_start;
	memcpy(&status, address + root_address, 1);
	memcpy(&file_start_block, address + root_address+1, 4);
	file_start_block = ntohl(file_start_block)*block_size;
	
	//go through the files
	while (status != 0) {
		if (status == 0x3) {

			//check if the file exist
			file_exist = strncmp(file_name, address + root_address + 27 + (64 * count), strlen(address + root_address + 27 + (64 * count)));
			if (file_exist == 0) {
				memcpy(&file_start_block, address + root_address+(count*64) + 1, 4);
				file_start_block = ntohl(file_start_block)*block_size;

				//get file size
				memcpy(&file_size, address + root_address + 9 + (64 * count), 4);
				file_size = ntohl(file_size);

				//write to file
				FILE * fp = fopen(file_name, "w");
				fwrite(address + file_start_block, file_size, 1, fp);
				fclose(fp);
				printf("File %s copied from file system is now on the current directory\n",file_name);
				return 0;
			}
			count++;
			memcpy(&status, address + root_address + (64 * count), 1);
		}
	}
	//if file not found
	printf("File not found\n");
	exit(0);
}