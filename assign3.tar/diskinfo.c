/*
*	CSC360 Assignment 03
*
*	Part I
*	
*	Student: Yaoxu Li 
*	V00908578
*	Descripyion: SuperBlock information
*	Credit: The method of using mmap() refrences previous years 360's tutorial
*/

#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <arpa/inet.h>

int main(int argc, char* argv[])
{
	//initialize
	int block_size = 0;
	int block_count = 0;
	int fat_starts = 0;
	int fat_blocks = 0;
	int root_start = 0;
	int root_blocks = 0;
	int tmp=0x0;
	int reserved = 0;
	int allocated = 0;
	int fd = open(argv[1], O_RDWR);
	struct stat buffer;
	int status = fstat(fd, &buffer);

	char* address = mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);


// IDENT_OFFSET		0
// BLOCKSIZE_OFFSET	8
// BLOCKCOUNT_OFFSET	10
// FATSTART_OFFSET		14
// FATBLOCKS_OFFSET	18
// ROOTDIRSTART_OFFSET	22
// ROOTDIRBLOCKS_OFFSET	26
	memcpy(&block_size, address + 8, 2);
	block_size = ntohs(block_size);
	memcpy(&block_count, address + 10, 4);
	block_count = ntohl(block_count);
	memcpy(&fat_starts, address + 14, 4);
	fat_starts = ntohl(fat_starts);
	memcpy(&fat_blocks, address + 18, 4);
	fat_blocks = ntohl(fat_blocks);
	memcpy(&root_start, address + 22, 4);
	root_start = ntohl(root_start);
	memcpy(&root_blocks, address + 26, 4);
	root_blocks = ntohl(root_blocks);

	
	memcpy(&tmp, address+64, 4);
	tmp = ntohl(tmp);

	//check reserved and allocated blocks
	int i = 0;
	while (i <block_count) {
		if (tmp == 0x00000001) {
			reserved++;
		}
		else if (tmp!=0x00) {
			allocated++;
		}
		memcpy(&tmp, address+64+(i*4), 4);
		tmp = ntohl(tmp);
		i++;
	}

	//print fommat result
	printf("Super block information: \n");
	printf("Block size: %d\n", block_size);
	printf("Block count: %d\n", block_count);
	printf("FAT starts: %d\n", fat_starts);
	printf("FAT blocks: %d\n", fat_blocks);
	printf("Root directory start: %d\n", root_start);
	printf("Root directory blocks: %d\n\n", root_blocks);
	printf("FAT information: \n");
	printf("Free Blocks: %d\n",block_count-reserved-allocated);
	printf("Reserved Blocks: %d\n",reserved);
	printf("Allocated Blocks: %d\n",allocated);



	munmap(address, buffer.st_size);

}