/*
*	CSC360 Assignment 03
*
*	Part II
*
*	Student: Yaoxu Li
*	V00908578
*	Descripyion: Display disk list
*	Credit: The method of using mmap() refrences previous years 360's tutorial
*/
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <arpa/inet.h>

int main(int argc, char* argv[])
{

	//initialize variables
	int root_start = 0;
	int block_size = 0;
	int root_address = 0;
	int status = 0;
	int file_size = 0;
	int count = 0;

	//time
	int year = 0;
	int month = 0;
	int day = 0;
	int hour = 0;
	int min = 0;
	int sec = 0;

	int fd = open(argv[1], O_RDWR);
	struct stat buffer;
	int sta = fstat(fd, &buffer);

	char* address = mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

	//get root directory
	memcpy(&block_size, address + 8, 2);
	block_size = ntohs(block_size);
	memcpy(&root_start, address + 22, 4);
	root_start = ntohl(root_start);
	root_address = block_size*root_start;

	memcpy(&status, address + root_address, 1);


	while (status != 0) {
		//file
		if (status == 0x3)
			printf("F ");
		//directory
		else if (status == 0x5)
			printf("D ");

		//print size
		//DIRECTORY_FILE_SIZE_OFFSET	9
		memcpy(&file_size, address + root_address + 9 + (64 * count), 4);
		file_size = ntohl(file_size);
		printf("%10d ",file_size);
		//print file name
		//DIRECTORY_FILENAME_OFFSET	  27
		printf("%30s ", address + root_address + 27 + (64 * count));
		

		//get modification time
		//DIRECTORY_MODIFY_OFFSET		20
		memcpy(&year, address + root_address + 20 + (64 * count), 2);
		year = ntohs(year);
		memcpy(&month, address + root_address + 22 + (64 * count), 1);
		memcpy(&day, address + root_address + 23 + (64 * count), 1);
		memcpy(&hour, address + root_address + 24 + (64 * count), 1);
		memcpy(&min, address + root_address + 25 + (64 * count), 1);
		memcpy(&sec, address + root_address + 26 + (64 * count), 1);

		//print time
		printf("%d/%02d/%02d %02d:%02d:%02d",year,month,day,hour,min,sec);
		count++;
		memcpy(&status, address + root_address + (64 * count), 1);
		printf("\n");
	}


}