/*
*
*	Student: Yaoxu Li   V00908578
*	CSC 360 Assignment 01
*	Description: A simple shell
*	Date: 2020/JUN/07
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include <assert.h>
//
// Credit: the following 3 lines code refernce-https://blog.csdn.net/xuancbm/article/details/81436681 
//			line 96 - 120 bglist refrences previous csc 360 's lab
// Set script color at linux environment
#define CLOSE "\001\033[0m\002"    
#define BLOD  "\001\033[1m\002"
#define BEGIN(x,y) "\001\033["#x";"#y"m\002"

#define _CRT_SECURE_NO_WARNINGS

//node struct
typedef struct node_t {
	pid_t pid;  // pid
	int status; // 1 running 0 stopped
	char process[256]; // name of process
	struct node_t  *next; //pointer to next node
} node_t;

//initialize new node
node_t *new_node(pid_t p, char *text) {
	assert(text != NULL);
	node_t *temp = (node_t *)malloc(sizeof(node_t));
	temp->pid = p;
	strcpy(temp->process, text);
	temp->status = 1;// change status for running process
	temp->next = NULL;
	return temp;
}

//add a node at end
node_t *add_end(node_t *list, node_t *new) {
	node_t *curr;
	if (list == NULL) {
		new->next = NULL;
		return new;
	}
	for (curr = list; curr->next != NULL; curr = curr->next);
	curr->next = new;
	new->next = NULL;
	return list;
}



int main(void)
{
	//background list(header)
	node_t *background = NULL;
	int i = 0;

	for (;;)
	{
		
		char** cmds = (char**)malloc(sizeof(char*) * 15);// allowcate memory for commands(parameters no more than 15) 
		for (i = 0; i < 15; i++)cmds[i] = NULL; //initialize with null
		char cwd[256];						// The�length�of�the�current�working�directory�is�less�than�256�character
		
		getcwd(cwd, 256);//get current directory

		//print "shell" and dir with color
		printf(BEGIN(49, 36) "myShell " CLOSE);
		printf(BEGIN(49, 32)"%s > "CLOSE, cwd);

		char * cmd = readline("");
		char cmdstr[256] = " ";
		strcpy(cmdstr,cmd);

		//divide commands in to arguments array
		cmds[0] = strtok(cmd," ");
		i = 0;
		while (cmds[i]!=NULL) {
			cmds[i + 1] = strtok(NULL, " ");
			i++;
		}

		//Part II changing directory
		if (strcmp(cmds[0], "cd") == 0) {
			if (cmds[1] == NULL || (strcmp(cmds[1],"~") == 0)) {
				chdir(getenv("HOME"));
			}
			else {
				chdir(cmds[1]);
			}
		}

		//Part III bg list
		else if (strcmp(cmds[0], "bglist") == 0) {
			if (background != NULL) {

				pid_t child = waitpid(-1, NULL, WNOHANG);

				while (child > 0) {
					if (child > 0) { //child terminates
						if (background->pid == child) {
							printf("%s has done\n", background->process);
							//change the header node
							background = background->next;
						}
						else {
							//search the node
							for (node_t * curr = background;curr!=NULL; curr = curr->next) {
								if (curr->next->pid == child) {
									printf("%s has done\n", curr->next->process);
									//remove the node
									if (curr->next->next == NULL) { curr->next = NULL; }
									else curr->next = curr->next->next;
								}
							}
						}
					}
					child = waitpid(0, NULL, WNOHANG);
				}

				//print the bg list
				i = 0;
				for (node_t * curr = background; curr != NULL; curr = curr->next) {
					if (curr->status == 0) {
						printf("%d[S]: executing %s\n", i, curr->process);
					}
					else {
						printf("%d[R]: executing %s\n", i, curr->process);
					}
					i++;
				}
				printf("Total background jobs: %d\n",i);
			}

			//no bg process
			else {
				printf("Nothing in bglist\nTotal background jobs: 0\n");
			}

		}


		//Part III bgkill
		else if (strcmp(cmds[0], "bgkill") == 0) {
			int num = atoi(cmds[1]);
			node_t * curr = background;
			for (i = 0;i<=num;i++,curr=curr->next) {
				if (curr == NULL) {
					printf("This job is not in the list now. Invalid\n");
					break;
				}
				else {
					if (i == num) {
						pid_t tmppid = curr->pid;
						printf("Job %d been killed by user  PID=%d\n",i, tmppid);
						kill(tmppid,SIGKILL);
						break;
					}
		
				}
			}

		}

		//Part IV "start" commands
		else if (strcmp(cmds[0], "start") == 0){
			int num = atoi(cmds[1]);
			node_t * curr = background;
			for (i = 0; i <= num; i++, curr = curr->next) {
				if (curr == NULL) {
					printf("This job is not in the list now. Invalid\n");
					break;
				}
				else {
					if (i == num) {
						pid_t tmppid = curr->pid;
						curr->status = 1;
						printf("Job %d been started by user  PID=%d\n", i, tmppid);
						kill(tmppid, SIGCONT);
						break;
					}
				}
			}
		}
		//Part IV "stop" commands
		else if (strcmp(cmds[0], "stop") == 0){
			int num = atoi(cmds[1]);
			node_t * curr = background;
			for (i = 0; i <= num; i++, curr = curr->next) {
				if (curr == NULL) {
					printf("This job is not in the list now. Invalid\n");
					break;
				}
				else {
					if (i == num) {
						curr->status = 0;
						pid_t tmppid = curr->pid;
						printf("Job %d been stopped by user  PID=%d\n", i, tmppid);
						kill(tmppid, SIGSTOP);
						break;
					}
				}
			}
		}

		//Part III execute background process
		else if (strcmp(cmds[0], "bg") == 0) {
			cmds++;
			pid_t p = fork();
			//child
			if (p == 0) {
				if (execvp(cmds[0], cmds) < 0) {
					printf("fail,invalid command\n");
					continue;
				}
				
			}
			//parents
			else {
				waitpid(p, NULL, WNOHANG);
				if (background == NULL) {
					background = new_node(p,cmdstr);
				}
				else {
					background = add_end(background,new_node(p,cmdstr));
				}
			}
		}

		//For Part I , execute a command
		else {
			pid_t p = fork();
			if (p == 0) {
				if (execvp(cmds[0], cmds) < 0) {
					printf("fail,invalid command\n");
					continue;
				}

			}
			else {
				waitpid(p, NULL, 0);
			}
		}
		//free memory
		free(cmd);
	}
}
