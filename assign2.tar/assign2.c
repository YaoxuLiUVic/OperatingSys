﻿/*
 * assign2.c
 *
 * Name:YAOXU LI
 * Student Number: V00908578
 *
 *
 *
 *   ****      READ ME PLEASE     *******
 *
 *
 * I am not sure if we should print all arrives/on/leave orders
 * or just orders of trains go off? 
 * If only get off orders is needed,
 * please comment line 89 and 90,  174, 175 and 176   and 271, 272 and 273
 * Thank you very much
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>
#include "train.h"

/*
 * If you uncomment the following line, some debugging
 * output will be produced.
 *
 * Be sure to comment this line out again before you submit 
 */

/* #define DEBUG	1 */


pthread_mutex_t lock; //mutex declaration
pthread_cond_t convarEast = PTHREAD_COND_INITIALIZER; //convar initialization
pthread_cond_t convarWest = PTHREAD_COND_INITIALIZER; //convar initialization
int current = 0; //if there is no train in the bridge, current = 0
int currentDirection; //direction of the train on bridge
int westIndex = 0; //
int eastIndex = 0; //
int westNum = 0; //num of current waiting trains(to west)
int eastNum = 0; //num of current waiting trains(to east)
int east[50];//stores train ID
int west[50];//
int priority=0;//to determine if a West train should go next
int ehead = 0;//index of head of waiting list
int whead = 0;

void ArriveBridge (TrainInfo *train);
void CrossBridge (TrainInfo *train);
void LeaveBridge (TrainInfo *train);

/*
 * This function is started for each thread created by the
 * main thread.  Each thread is given a TrainInfo structure
 * that specifies information about the train the individual 
 * thread is supposed to simulate.
 */
void * Train ( void *arguments )
{
	TrainInfo	*train = (TrainInfo *)arguments;

	/* Sleep to simulate different arrival times */
	usleep (train->length*SLEEP_MULTIPLE);

	ArriveBridge (train);
	CrossBridge  (train);
	LeaveBridge  (train); 

	/* I decided that the paramter structure would be malloc'd 
	 * in the main thread, but the individual threads are responsible
	 * for freeing the memory.
	 *
	 * This way I didn't have to keep an array of parameter pointers
	 * in the main thread.
	 */
	free (train);
	return NULL;
}

/*
 * You will need to add code to this function to ensure that
 * the trains cross the bridge in the correct order.
 */
void ArriveBridge ( TrainInfo *train )
{
	printf ("Train %2d arrives going %s\n", train->trainId, 
			(train->direction == DIRECTION_WEST ? "West" : "East"));
	/* Your code here... */


	if (current == 1 ||eastNum!=0|| westNum!=0 ) {

		//if a train should wait
		//then put it in to waiting list
		if (train->direction == DIRECTION_WEST) {
			west[westIndex] = train->trainId;//
			westIndex++;
			westNum++;
		}
		else {
			east[eastIndex] = train->trainId;//
			eastIndex++;
			eastNum++;
		}

		//if the train goes to east
		if (train->direction == DIRECTION_EAST) {

			//if the train is the head of wating list of east
			//then prepare to collecting signal for condition variable
			if (east[ehead] == train->trainId) {
				pthread_cond_wait(&convarEast, &lock);
				current = 1;
				ehead++;
			}
			//else until the train become the head of wait list
			else {
				while (1) {
					if (east[ehead] == train->trainId) {
						pthread_cond_wait(&convarEast, &lock);
						current = 1;
						break;
					}
				}
				ehead++;
			}
			//pthread_mutex_lock(&lock);
			currentDirection = train->direction;
			
		}

		//if the train goes to west
		else {
			//if the train is the head of wating list of west
			//then prepare to collecting signal for condition variable
			if (west[whead] == train->trainId) {
				pthread_cond_wait(&convarWest, &lock);
				current = 1;
				whead++;
			}
			//else until the train become the head of wait list of west
			else {
				while (1) {
					if (west[whead] == train->trainId) {
						pthread_cond_wait(&convarWest, &lock);
						current = 1;
						break;
					}
				}
				whead++;
			}
			currentDirection = train->direction;

		}
	}

	//if no need to wait(no train on the bridge or on waiting)
	else {
		pthread_mutex_lock(&lock);
		current = 1;
		currentDirection = train->direction;
	}
}

/*
 * Simulate crossing the bridge.  You shouldn't have to change this
 * function.
 */
void CrossBridge ( TrainInfo *train )
{
	printf ("Train %2d is ON the bridge (%s)\n", train->trainId,
			(train->direction == DIRECTION_WEST ? "West" : "East"));
	fflush(stdout);
	
	/* 
	 * This sleep statement simulates the time it takes to 
	 * cross the bridge.  Longer trains take more time.
	 */
	usleep (train->length*SLEEP_MULTIPLE);

	printf ("Train %2d is OFF the bridge(%s)\n", train->trainId, 
			(train->direction == DIRECTION_WEST ? "West" : "East"));
	fflush(stdout);
}

/*
 * Add code here to make the bridge available to waiting
 * trains...
 */
void LeaveBridge ( TrainInfo *train )
{
	//train leaves 
	current = 0;
	if (westNum != 0 && currentDirection== DIRECTION_EAST) { 
		priority++; 
	}
	//if priority = 2, next should for west
	if (priority == 2&&westNum!=0) {
		priority = 0;
		westNum--;
		pthread_cond_signal(&convarWest);

	}
	//east has higher priority in normal case
	else if (eastNum != 0) {
		eastNum--;
		pthread_cond_signal(&convarEast);
	}

	else if (eastNum==0&&westNum==0) {
		pthread_cond_signal(&convarWest);
	}
	//west has lower priority in normal case
	else {
		westNum--;
		pthread_cond_signal(&convarWest);
		
	}

	//unlock after the train leave
	pthread_mutex_unlock(&lock);
	
	
}

int main ( int argc, char *argv[] )
{
	int		trainCount = 0;
	char 		*filename = NULL;
	pthread_t	*tids;
	int		i;
	pthread_mutex_init(&lock, NULL);
		
	/* Parse the arguments */
	if ( argc < 2 )
	{
		printf ("Usage: part1 n {filename}\n\t\tn is number of trains\n");
		printf ("\t\tfilename is input file to use (optional)\n");
		exit(0);
	}
	
	if ( argc >= 2 )
	{
		trainCount = atoi(argv[1]);
	}
	if ( argc == 3 )
	{
		filename = argv[2];
	}	
	
	initTrain(filename);
	usleep(1);
	/*
	 * Since the number of trains to simulate is specified on the command
	 * line, we need to malloc space to store the thread ids of each train
	 * thread.
	 */
	tids = (pthread_t *) malloc(sizeof(pthread_t)*trainCount);
	
	/*
	 * Create all the train threads pass them the information about
	 * length and direction as a TrainInfo structure
	 */
	for (i=0;i<trainCount;i++)
	{
		TrainInfo *info = createTrain();
		
		printf ("Train %2d headed %s length is %d\n", info->trainId,
			(info->direction == DIRECTION_WEST ? "West" : "East"),
			info->length );

		//thread creation
		if ( pthread_create (&tids[i],0, Train, (void *)info) != 0 )
		{
			printf ("Failed creation of Train.\n");
			exit(0);
		}
	}

	/*
	 * This code waits for all train threads to terminate
	 */
	for (i=0;i<trainCount;i++)
	{
		pthread_join (tids[i], NULL);
	}
	
	free(tids);
	return 0;
}

